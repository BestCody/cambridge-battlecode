set(CMAKE_HOST_SYSTEM "Windows-10.0.26200")
set(CMAKE_HOST_SYSTEM_NAME "Windows")
set(CMAKE_HOST_SYSTEM_VERSION "10.0.26200")
set(CMAKE_HOST_SYSTEM_PROCESSOR "AMD64")

include("C:/Users/joshu/AppData/Local/cambc/wasi-sdk-33/share/cmake/wasi-sdk-p1.cmake")

set(CMAKE_SYSTEM "WASI-1")
set(CMAKE_SYSTEM_NAME "WASI")
set(CMAKE_SYSTEM_VERSION "1")
set(CMAKE_SYSTEM_PROCESSOR "wasm32")

set(CMAKE_CROSSCOMPILING "TRUE")

set(CMAKE_SYSTEM_LOADED 1)
